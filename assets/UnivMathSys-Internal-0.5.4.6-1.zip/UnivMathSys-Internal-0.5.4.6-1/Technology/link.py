# Linking File of Universal Mathematics System

    # Copyright (C) 2016 Zhang Chang-kai #
    # Contact via: phy.zhangck@gmail.com #
    # General Public License version 3.0 #

'''Linking File of UnivMathSys'''

# End of Linking File of UnivMathSys
