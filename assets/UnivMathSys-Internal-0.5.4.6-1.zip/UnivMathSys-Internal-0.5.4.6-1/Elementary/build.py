# Build-in Default Functions for UnivMathSys

    # Copyright (C) 2016 Zhang Chang-kai #
    # Contact via: phy.zhangck@gmail.com #
    # General Public License version 3.0 #

'''Module Elementary.build of UnivMathSys'''

def TrueFunc(*args):
    return True

def FalseFunc(*args):
    return False

# End of Module Elementary.build of UnivMathSys
